import sys

cmds = sys.argv

for cmd in cmds[1:]:
    print(cmd)
