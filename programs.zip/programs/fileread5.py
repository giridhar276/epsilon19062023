

#write a program to display the below output:

#Total no. of observations : 32562


with open('adult.csv','r') as fobj:
    lines = fobj.readlines()
    print("total no. ofobservations:",len(lines))
    
    
    
    
line_count= 0
with open('adult.csv','r') as fobj:
    for line in fobj:
        line_count = line_count + 1
    print("total no. ofobservations:",line_count)