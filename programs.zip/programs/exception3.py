try:
    fobj =  open('lang.txt','r')

except FileNotFoundError as err:
    print(err)
    print("file is not found")
except TypeError as err:
    print(err)
    print("Invalid operation")
except (IndexError,KeyError) as err:
    print(err)
except Exception  as err:  # generic exception applicable for any kind of exception
    print("system error :", err)
else:
    try:
        for line in fobj:
            # remove white spaces if any
            line = line.strip()
            print(line)    
    except Exception as err:
        print(err)
finally:
    print('this block will be executed all the times')