name= 'python programming'
print(name)
print('I love',name)

#slicing - extract some part of this string
#string[start:stop:incremental]
print(name)
print(name[0])
print(name[1])
print(name[2])
print(name[0:10])
print(name[8:10])
print(name[1:5])
print(name[0:18:2])
print(name[1:18:2])
print(name[:]) # python programming
print(name[::])# python programming


name= 'python programming'
print(name.upper())
print(name.lower())

print(name.isupper())
print(name.islower())

print(name.count('p'))

print(name.replace('python','java'))

print(name.capitalize())

print(name.title())
# check for substring in
print(name.find('in'))  # will return the index number
print(name.find('qw'))  # will return -1 if not existing

print(name.startswith('p'))
print(name.startswith('q'))

print(name.endswith('g'))
print(name.endswith('q'))

# string with place holders
aname = 'I love {} and {}'
print(aname.format('unix','java'))
print(aname.format('java','linux'))
ip = "192,168.0.{}"
print(ip.format(1))
print(ip.format(2))

bname = ' python  '
print(len(bname))

print(len(bname.strip()))  # will remove white spaces at ends
print(len(bname.lstrip()))
print(len(bname.rstrip()))

cname = 'python:unix:java'
print(cname.split(':'))

dname = 'unix programming'
print(dname.split(" "))

























