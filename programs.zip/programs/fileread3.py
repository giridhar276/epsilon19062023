


import csv
with open('adult.csv','r') as fobj:
    # covert file object to csv object
    reader = csv.reader(fobj)
    for line in reader:
        #print(line) # each line will be  converted to list automatically
        print('Workclass:',line[1])
        print('Education :',line[3])
        print("-------------------")

