
'''

write a program toread drinks.csv and display the below output:

AS
----
all the countires inthe continent AS

EU
----
all the countries in the EU continent
'''

continents = set()

import csv
with open('drinks.csv','r') as fobj:
    header = fobj.readline()
    # covert file object to csv object
    reader = csv.reader(fobj)
    for line in reader:
        continents.add(line[-1])
    conti_dict = dict.fromkeys(continents,set())
print(conti_dict) 
with open('drinks.csv','r') as fobj:
    header = fobj.readline()
    # covert file object to csv object
    reader = csv.reader(fobj)
    for line in reader:
        continent = line[-1]
        conti_dict[continent].add(line[0])
        
print(conti_dict['EU'])