###################### fixed arguments #############################
# function definition
def add(a,b):
    c = a + b
    print(c)

#calling function
add(10,20)

########################### default arguments #########################
# function definition
def add(a = 0,b = 0,c = 0):
    print(a,b,c)

#calling function
add()
add(10)
add(10,20)
add(10,20,30)

##################### keyword arugments ###########################
def add(b,a,c):
    print(a,b,c)
add(a = 10,b =20, c = 30)

# example of keyword arguments
print(10,20)
print(30)

print(10,20,30,sep = "       ",end = "\n\n\n\n")
print(30)

# example of keyword arguments
line = "a:b:c"
print(line.split(":"))
print(line.split(sep = ":"))

# example of default arguments
def fileread(filename = 'lang.txt'):
    with open(filename,'r') as fr:
        for line in fr:
            print(line)
fileread()
fileread('adult.csv')
        


#keyword arguments
# If any object is prefixed with * - we call it as tuple
def display(*kargs):
    for val in kargs:
        print(val)
        
display(10,20,30,40,50,'unix')





