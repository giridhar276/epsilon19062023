# method1
#importing all the methods
# all the methods will be imported to program space
import math
print(math.log(2))
print(math.tan(1))

#method2
# importing with alias name
import math as m
print(m.log(2))
print(m.tan(1))

#method3
#importing required methods only
# . is not required here
from math import floor,ceil,tan
print(floor(34.2))
print(ceil(34.2))
print(tan(1))

#method4 - importing all the methods
from math import *
print(floor(34.2))
print(ceil(34.2))
print(tan(1))