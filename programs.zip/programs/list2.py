


#list
alist = [10,20,30,40,50]
alist[0] = 100
print('After replacing :',alist)



# tuple is immutable
# tuple
atup = (45,56,78)
atup[0] = 450
print('After replacing :',atup)


# can be modified with type casting
# converting from one ojbect to another object


atup = (45,56,78)
# converting to list
alist = list(atup)
alist.append(500)
# recoverting back to tuple
atup  = tuple(alist)
print('After replacing :',atup)


# list of lists
employees = [['ram','1-1-1990','US'],['rita','2-2-1989']]

# list of tuples
employees = [('ram','1-1-1990','US'),('rita','2-2-1989')]
employees.pop(0)
print(employees)




