
# requirement - connect to cloud and download, validate and connect db


def connect_aws():
    ###
    
def downloadfiles():
    ###
    
def validate():
    ##
    
def connectdb():
    ###
    
    
# calling user dfined functions
connect_aws()
downloadfiles()
validate()
connectdb()



downloadfiles()


downloadfiles()



downloadfiles()