

import json

with open('sample4.json','r') as fobj:
    data = json.load(fobj)
    for item in data['people']:
        if item['lastName'] == 'Smith':
            print(item['firstName'])
            print(item['lastName'])
            print(item['gender'])
            print("----------------")