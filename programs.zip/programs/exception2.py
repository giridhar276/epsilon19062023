
try:
    with open('lang1.txt','r') as fobj:
        for line in fobj:
            # remove white spaces if any
            line = line.strip()
            print(line)
    for val in range(1,11):
        ip = '192.168.0.{}'
        print(ip.format(val))
        
    
    for val in range(1,11):
        ip = "192.168.0."
        print(ip + str(val))

            
except FileNotFoundError as err:
    print(err)
    print("file is not found")
except TypeError as err:
    print(err)
    print("Invalid operation")
except (IndexError,KeyError) as err:
    print(err)
except Exception  as err:  # generic exception applicable for any kind of exception
    print("system error :", err)
    
try:
    for val in range(1,11):
        ip = "192.168.0."
        print(ip + str(val))
except Exception as err:
    print(err)
        