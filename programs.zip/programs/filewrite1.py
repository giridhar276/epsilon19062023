
#writing to a file
fobj = open('languages.txt','w')
fobj.write('python programming\n')
fobj.write('unix shell scripting\n')
fobj.write('java\n')
fobj.close()


# writing numbers to a file
fobj = open('numbers.txt','w')
for val in range(1,11):
    fobj.write( str(val) + "\n")
fobj.close()

## if the file has to be created in different path 
# writing numbers to a file
fobj = open('C:\\Users\\Administrator\\Desktop\\numbers.txt','w')
for val in range(1,11):
    fobj.write( str(val) + "\n")
fobj.close()

fobj = open(r'C:\Users\Administrator\Desktop\numbers.txt','w')  # raw string
for val in range(1,11):
    fobj.write( str(val) + "\n")
fobj.close()

fobj = open('C:/Users/Administrator/Desktop/numbers.txt','w')  # raw string
for val in range(1,11):
    fobj.write( str(val) + "\n")
fobj.close()