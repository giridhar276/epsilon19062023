book  = {'chap1':10 ,'chap2':20 ,'chap3':30}
book  = {'chap1':10 ,'chap2':20 ,'chap3':30,'chap1':1000}
print(book)

# display individual values
print(book['chap1'])
print(book['chap2'])
print(book['chap3'])
# add new key-values
book['chap4'] = 40
book['chap5'] = 50
print(book)
# display the keys only
print(book.keys())
# displsay values
print(book.values())

# display items
print(book.items())

book.pop('chap1')  # chap1-10 will be removed from dictionary
print(book)

book.popitem()
print(book)

newbook = {"chap7":70,"chap8":80}
book.update(newbook)
print(book)
#print(book['chap10'])
# if chap10 is existing.. it returns the value
print(book.get('chap4'))
# if chap10 is not existing.. it returns None
print(book.get('chap10'))





