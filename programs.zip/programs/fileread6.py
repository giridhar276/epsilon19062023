

#write a program to read adult.csv and display all distinct workclasses


workclass_set = set()
import csv
with open('adult.csv','r') as fobj:
    # covert file object to csv object
    reader = csv.reader(fobj)
    for line in reader:
        workclass = line[1]
        if not "?" in workclass:
            workclass_set.add(workclass)
    
    for item in workclass_set:
        print(item.strip())
        
        
        
workclass_dict = dict()
import csv
with open('adult.csv','r') as fobj:
    # covert file object to csv object
    reader = csv.reader(fobj)
    for line in reader:
        workclass = line[1]
        if not "?" in workclass:
            workclass_dict[workclass] = 1
    
    for item in workclass_dict:
        print(item.strip())
        
        
        
        
        