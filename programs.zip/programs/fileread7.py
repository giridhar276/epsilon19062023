
'''
#write a program to read adult.csv and display the total count of Male and Female

Output:
Total male count :   xxx
Total female count:  xx
'''


import csv
mcount = 0
fcount = 0
with open('adult.csv','r') as fobj:
    with open('adult_lower.csv','w') as fw:
        for line in fobj:
            line = line.strip().lower()
            fw.write(line + "\n")