
import paramiko


with open('severs.txt','r') as fobj:
    for server in fobj:
        server = server.strip()
        command = "df"
        # Update the next three lines with your
        # server's information
        host = server
        username = "YOUR_LIMITED_USER_ACCOUNT"
        password = "YOUR_PASSWORD"
        
        client = paramiko.client.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(host, username=username, password=password)
        _stdin, _stdout,_stderr = client.exec_command("df")
        #print(_stdout.read().decode())
        filename = server + "_output.txt"
        with open(filename,'w') as fobj:
            fobj.write(_stdout.read().decode())
        client.close()