

'''
write a program to capture 2 numbers from the keyboard and display its sum


Enter first number : 10
Enter second number: 20

Total : 30
'''



first = input('Enter first number:')
second = input("Enter second number :")

output  = int(first) + int(second)
print("SUm of numbers :",output)