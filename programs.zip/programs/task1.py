
'''
write a  program to read filename with extension from the keyboard and the file and extension separately.


OUtput:

Enter any filname : info.py

Filename : info
extension: py
'''


filename= input("Enter any filename:")

data = filename.split(".")
print("filename :",data[0])
print("extension:",data[1])