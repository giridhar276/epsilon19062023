# method1
# fobj acts like file pointer
with open('lang.txt','r') as fobj:
    for line in fobj:
        line = line.strip()
        print(line)
#method2
# usin fobj.readlines()
with open('lang.txt','r') as fobj:
    print(fobj.readlines())
    

with open('lang.txt','r') as fobj:
    for line in fobj.readlines():
        print(line)
        
#method3 - read the file all at once
with open('lang.txt','r') as fobj:
    print(fobj.read())
    
#method4
import csv
with open('lang.txt','r') as fobj:
    # covert file object to csv object
    reader = csv.reader(fobj)
    for line in reader:
        print(line) # each line will be  converted to list automatically