
'''

define some list as below

domains = ["google","www.unix","oracle.com"]

write a program

to add "www"  at the beginning  if the string is not starting with "www"
  and
".com" at the end of each string if the string is not ending with ".com"

Output:
www.google.com
www.unix.com
www.oracle.com
'''


domains = ["google","www.unix","oracle.com"]
for item in domains:
    if not item.startswith('www'):
        item = "www." + item
    if not item.endswith(".com"):
        item = item + ".com"
    print(item)
    
    
# appendin everything to the list
newdomains = [] 
domains = ["google","www.unix","oracle.com"]
for item in domains:
    if not item.startswith('www'):
        item = "www." + item
    if not item.endswith(".com"):
        item = item + ".com"
    newdomains.append(item)
print(newdomains)