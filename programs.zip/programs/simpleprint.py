

'''
print()

print('hello python')

print("spark")

print(10,20,30,40)

print("unix","java")

val = 10
print(val)
print("value is",val)
'''


"""
all these
lines
are
commented

"""
print('test')