

# traditional way to write to a file
#writing to a file
fobj = open('languages.txt','w')
fobj.write('python programming\n')
fobj.write('unix shell scripting\n')
fobj.write('java\n')
fobj.close()


# pythonic way
# context manager
# if any line starts with keyword with ... we call it as context manager
# Advantage : the file gets closed automatically when it comes out of the block

with open('languages.txt','w') as fobj:
    fobj.write('python programming\n')
    fobj.write('unix shell scripting\n')
    fobj.write('java\n')
