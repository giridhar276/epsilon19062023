alist = [95,95,12,34,1,23,67,3,61,91,5]
#slicing
print(alist[0:4])
# methods
# adding single element
alist.append(95)
print('After appending:',alist)
# adding multiple elements
alist.extend([98,59,8,39])
print('After extending :',alist)
#alist.insert(index,value) - inserting at any location
alist.insert(1,200)
print('after inserting :',alist)
# remove element with indexing
alist.pop(4)   # 4 is the index  # pop methods works with index
print('After pop:',alist)
# list.remove(value)   
alist.remove(91)  # 91 is the value in the list
print(alist)
# soring the values in ascending order
alist.sort()
print('After sorting :',alist)
alist.reverse()
print('After reversing :',alist)
getcount = alist.count(12)
print('12 is repeated for',getcount,"time")
# to find the index
print(alist.index(98))


