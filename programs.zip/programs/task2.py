
book = {"chap1":[10,'UK'] ,"chap2":[20,'US']}

book['chap1'].append('200pages')
book['chap2'].append('400pages')

print(book)




book = {"chap1":[10,'UK','Mark'] ,"chap2":[20,'US','Pet']}

book['chap1'][2] = '200pages'
book['chap2'][2] = '400pages'
print(book)

