

#set is unordered collection of unique items of same type
aset = {10,10,20,30,30,30}
bset = {30,30,30,30,40,40,40,50}

print(aset)
print(bset)

aset.add(30)
print(aset)
aset.add(300)
print(aset)

# all the unique elements of both the sets
print(aset.union(bset))

# elements which are common in both the sets
print(aset.intersection(bset))

# removing all the elements of bset from aset
print(aset.difference(bset))

print(aset.issubset(bset))