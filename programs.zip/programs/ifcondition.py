# simple if
a = 10
b = 2
if a > b :
    print('A is greater than B')
    print('inside if')
    print('still inside if')
print('regular code')    


# if else
a = 10
b = 2
if a > b :
    print('A is greater than B')
    print('inside if')
    print('still inside if')
else:
    print('B is greater than A')
    print('Inside else')
    print('inside else')
    
    
name = 'python'
if name.isupper():
    print('string is upper')
else:
    print('string is lower')
    
    
if name.startswith('p')  and  len(name) == 6:
    print("Its python")
else:
    print('its some other language')
    
    
    
    
    
    
if name.startswith('p')  and  len(name) == 6:
    if name.endswith('y'):
        print('its python')
    else:
        print('its perl')
else:
    print('its some other language')
    
    
    
    
# if elif-elif-else
lang = input('Enter any language:')
if lang == 'python':
    print('its python')
elif lang == 'perl':
    print('its perl')
elif lang == 'java':
    print('its java')
elif lang == 'oracle':
    print('its oracle')
else:
    print('its some other language')
    
    
    
    


    
    
    
    
    
    