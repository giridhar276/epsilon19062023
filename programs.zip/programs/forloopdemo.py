# display numbers from 1 to 10
for val in range(1,11):
    print(val)
    
for val in range(10,0,-1):
    print(val)  
    
# iterate the string
name = 'python'
for char in name:
    print(char)
    
#list
alist = [10,20,30]
for val in alist:
    print(val)
    
#tuple
atup = (40,50,60)
for val in atup:
    print(val)
    
# dictionary keys
book = {"chap1":10,"chap2":20}
for key in book.keys():
    print(key)

book = {"chap1":10,"chap2":20}
for key in book:
    print(key)
    
for value in book.values():
    print(value)
    
for key,value in book.items():
    print(key,value)
    
# set
aset = {10,10,10,20,30}

for val in aset:
    print(val)


    
    
    
    
    
    